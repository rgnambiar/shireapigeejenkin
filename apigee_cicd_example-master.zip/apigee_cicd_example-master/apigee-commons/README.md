# Build steps for common Project

# Navigate to the apigee-commons folder and run below command
mvn clean install